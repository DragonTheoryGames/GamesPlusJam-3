﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnterRoom : MonoBehaviour
{
    public GameObject door;
    public float yEnterRotation;
    public float yEnterRotationHolder;
    public float doorNegativeMovement;
    public float doorPositionMovement;
    public int negativeFor;
    public int positiveFor;
    public bool plus;
    public bool negative;


    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
       
        
    }

    void OnTriggerEnter(Collider doorMove)
    {
        if(doorMove.gameObject.name == "Ghost")
        {
            GameObject.Find("Door Exit Trigger").GetComponent<Collider>().enabled = false;
                if(plus == true)
                {
                    if(yEnterRotation <= yEnterRotationHolder)
                    {
                        for(int i = 0; i < positiveFor; i++)
                        {
                            yEnterRotation = yEnterRotation + doorPositionMovement;
                            door.transform.Rotate(0, yEnterRotation, 0);
                        }

                    }
                    //Turning off the collider to prevent the door from moving again until it is time
                    GameObject.Find("Door Enter Trigger").GetComponent<Collider>().enabled = false; 
                }
        }
                if(negative == true)
                {
                    if(yEnterRotation >= yEnterRotationHolder)
                    {
                        for(int i = 0; i < negativeFor; i++)
                        {
                            yEnterRotation = yEnterRotation + doorNegativeMovement;
                            door.transform.Rotate(0, yEnterRotation, 0);
                            
                        }
                    }
                    //Turning off the collider to prevent the door from moving again until it is time
                    GameObject.Find("Door Enter Trigger").GetComponent<Collider>().enabled = false;
                }   
               
    }

}
